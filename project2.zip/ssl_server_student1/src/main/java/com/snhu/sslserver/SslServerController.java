package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
class SslServerController{
	@RequestMapping("hash")
	public String myHash() throws NoSuchAlgorithmException{
		String data = "Hello World Check Sum!";
		String name = "Mihir Patel";
		String[ ] splitname = name.split(" ");
		String firstname = splitname[0];
		String lastname = splitname[splitname.length - 1];
		name = firstname+" "+ lastname;
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] sha256 = md.digest(name.getBytes(StandardCharsets.UTF_8));
		return "data: " + data + "</br></br>" + "Name: " + name + "</br></br>" + "Name of Cipher Algorithm Used: CheckSum Value: "+ bytesToHex(sha256);
		
	}
	public String bytesToHex(byte[] sha256) {
		BigInteger hex = new BigInteger(1, sha256);
		StringBuilder checksum = new StringBuilder(hex.toString(16));
		while (checksum.length() < 32) {
			checksum.insert(0,  '0');
		}
		return checksum.toString();
	}
}