package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslServerStudent1Application {

	public static void main(String[] args) {
		SpringApplication.run(SslServerStudent1Application.class, args);
	}

}


